package com.subway.controller.ui

import android.app.Activity
import android.view.View
import android.widget.LinearLayout
import com.subway.controller.PresetRepository
import com.subway.controller.models.Macro

class PresetsPage(private val act: Activity, private val host: Host) : Page {
    override val title = "Preset"
    override val view: View
    private val list: LinearLayout

    init {
        val (sv, c) = scrollPage(act)
        view = sv
        c.addView(Ui.text(act, "Preset", 22f, Ui.TEXT, true))
        c.addView(Ui.muted(act, "Các combo đã lưu trên máy này. Không có đồng bộ đám mây."))
        c.addView(Ui.text(act, "", 6f))
        list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        c.addView(list, Ui.lp())
        refresh()
    }

    override fun refresh() {
        list.removeAllViews()
        val presets = PresetRepository.all()
        if (presets.isEmpty()) {
            list.addView(Ui.muted(act, "Chưa có preset nào. Hãy lưu từ tab Macro hoặc Ghi combo."))
            return
        }
        for (m in presets) list.addView(row(m))
    }

    private fun row(m: Macro): View {
        val card = Ui.card(act)
        card.addView(Ui.text(act, m.name, 16f, Ui.TEXT, true))
        val rep = if (m.infinite) "lặp ∞" else "lặp ×${m.repeat}"
        card.addView(Ui.muted(act, "${m.actions.size} bước • $rep"))
        card.addView(Ui.text(act, m.summary().ifBlank { "(trống)" }, 18f, Ui.ACCENT))
        val r1 = Ui.row(act)
        r1.addView(Ui.primaryButton(act, "Tải") {
            PresetRepository.saveWorking(m.copy(id = java.util.UUID.randomUUID().toString()))
            Ui.toast(act, "Đã tải “${m.name}” vào Macro Editor")
            host.showPage(Host.EDITOR)
        }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        r1.addView(Ui.button(act, "Đổi tên") {
            Ui.prompt(act, "Đổi tên preset", m.name) { n ->
                PresetRepository.rename(m.id, n)
                refresh()
            }
        }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        card.addView(r1, Ui.lp(margin = 0).apply { topMargin = act.dp(8) })
        val r2 = Ui.row(act)
        r2.addView(Ui.button(act, "Nhân bản") {
            PresetRepository.duplicate(m.id)
            refresh()
        }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        r2.addView(Ui.button(act, "Xóa", Ui.DANGER, android.graphics.Color.WHITE) {
            Ui.confirm(act, "Xóa preset “${m.name}”?") {
                PresetRepository.delete(m.id)
                refresh()
            }
        }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        card.addView(r2, Ui.lp())
        return card
    }
}
