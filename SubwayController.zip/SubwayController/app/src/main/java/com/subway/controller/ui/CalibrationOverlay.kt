package com.subway.controller.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import com.subway.controller.SettingsRepository
import com.subway.controller.models.Direction
import com.subway.controller.util.Device

/**
 * Vẽ tạm thời (không nhận chạm) điểm bắt đầu và điểm kết thúc của 4 hướng vuốt lên màn hình,
 * để người dùng hiệu chỉnh tọa độ trùng với khu vực chơi của game.
 */
object CalibrationOverlay {
    private val handler = Handler(Looper.getMainLooper())
    private var view: View? = null
    private var hideTask: Runnable? = null

    fun show(ctx: Context, seconds: Int = 6): Boolean {
        val app = ctx.applicationContext
        if (!Device.canDrawOverlays(app)) return false
        hide(app)
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = MarkerView(app)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        return try {
            wm.addView(v, lp)
            view = v
            val task = Runnable { hide(app) }
            hideTask = task
            handler.postDelayed(task, seconds * 1000L)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide(ctx: Context) {
        hideTask?.let { handler.removeCallbacks(it) }
        hideTask = null
        val v = view ?: return
        view = null
        try {
            (ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: IllegalArgumentException) {
            // đã bị gỡ
        }
    }

    private class MarkerView(ctx: Context) : View(ctx) {
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3DDC84.toInt() }
        private val endPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF5A623.toInt() }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCFFFFFF.toInt()
            strokeWidth = ctx.dp(3).toFloat()
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = ctx.dp(16).toFloat()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = SettingsRepository.load()
            val (w, h) = Device.screenSize(context)
            // Quy đổi từ tọa độ màn hình thật sang tọa độ của cửa sổ này.
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            val ox = loc[0]
            val oy = loc[1]
            val sx = w * s.startXPct / 100f
            val sy = h * s.startYPct / 100f
            for (d in Direction.values()) {
                val dist = (if (d == Direction.LEFT || d == Direction.RIGHT) w else h) * s.distancePct / 100f
                var ex = sx
                var ey = sy
                when (d) {
                    Direction.UP -> ey = sy - dist
                    Direction.DOWN -> ey = sy + dist
                    Direction.LEFT -> ex = sx - dist
                    Direction.RIGHT -> ex = sx + dist
                }
                ex = ex.coerceIn(1f, w - 1f)
                ey = ey.coerceIn(1f, h - 1f)
                canvas.drawLine(sx - ox, sy - oy, ex - ox, ey - oy, linePaint)
                canvas.drawCircle(ex - ox, ey - oy, context.dp(10).toFloat(), endPaint)
                canvas.drawText(d.arrow, ex - ox + context.dp(14), ey - oy, textPaint)
            }
            canvas.drawCircle(sx - ox, sy - oy, context.dp(14).toFloat(), dotPaint)
            canvas.drawText("Điểm bắt đầu", sx - ox + context.dp(18), sy - oy - context.dp(18), textPaint)
        }
    }
}
