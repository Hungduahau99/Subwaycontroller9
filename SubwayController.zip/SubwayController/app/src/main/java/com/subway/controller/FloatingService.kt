package com.subway.controller

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.subway.controller.ui.Ui
import com.subway.controller.ui.dp
import com.subway.controller.util.Device
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Bảng điều khiển nổi (WindowManager + TYPE_APPLICATION_OVERLAY), chạy trong foreground service. */
class FloatingService : Service() {

    companion object {
        val running = MutableStateFlow(false)
        const val ACTION_STOP = "com.subway.controller.action.STOP"
        private const val CHANNEL = "floating_controller"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var statusView: TextView? = null
    private var recBtn: TextView? = null
    private var panelOpen = false
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        if (root != null) buildOverlay()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        SettingsRepository.changeSource().registerOnSharedPreferenceChangeListener(prefListener)
        uiScope.launch {
            MacroEngine.status.collect { st -> statusView?.text = MacroEngine.describe(st) }
        }
        uiScope.launch {
            ComboRecorder.state.collect { st ->
                recBtn?.text = if (st.recording) "■ Ghi (${st.actions.size})" else "● Ghi"
                recBtn?.background = Ui.pressable(if (st.recording) Ui.DANGER else Ui.SURFACE2, dp(10).toFloat())
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!Device.canDrawOverlays(this)) {
            // Quyền bị thu hồi: dừng êm, không crash.
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) buildOverlay()
        running.value = true
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Xoay màn hình / đổi độ phân giải: đưa bảng nổi về lại trong màn hình.
        root?.post { clampAndApply() }
    }

    override fun onDestroy() {
        running.value = false
        // Overlay bị gỡ => không còn gì điều khiển macro: dừng để an toàn.
        if (MacroEngine.status.value.active) MacroEngine.stop("Bảng điều khiển nổi đã đóng — macro đã dừng")
        ComboRecorder.stop()
        try {
            SettingsRepository.changeSource().unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (_: Exception) {
        }
        removeOverlay()
        uiScope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Subway Controller", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Subway Controller")
            .setContentText("Bảng điều khiển nổi đang bật")
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tắt", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- overlay

    private fun removeOverlay() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: IllegalArgumentException) {
            }
        }
        root = null
        panel = null
        statusView = null
        recBtn = null
    }

    private fun buildOverlay() {
        removeOverlay()
        val s = SettingsRepository.load()
        val scale = s.overlaySizePct / 100f
        val cell = dp((46 * scale).toInt())

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.alpha = s.overlayAlphaPct / 100f

        // --- nút tròn mở/đóng bảng (cũng là tay nắm kéo) ---
        val bubble = TextView(this).apply {
            text = "S"
            textSize = 18f * scale
            setTextColor(Ui.ON_ACCENT)
            gravity = Gravity.CENTER
            background = Ui.rounded(Ui.ACCENT, dp(40).toFloat())
            setOnTouchListener(DragListener { togglePanel() })
        }
        container.addView(bubble, LinearLayout.LayoutParams(cell, cell))

        // --- bảng điều khiển ---
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(8), dp(8), dp(8), dp(8))
        p.background = Ui.rounded(Color.parseColor("#E61A1A1A"), dp(14).toFloat())
        p.setOnTouchListener(DragListener(null)) // kéo bằng phần viền của bảng

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val st = Ui.text(this, MacroEngine.describe(MacroEngine.status.value), 11f * scale, Ui.TEXT)
        st.maxWidth = dp((190 * scale).toInt())
        statusView = st
        top.addView(st, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        top.addView(
            Ui.smallButton(this, "✕", Ui.DANGER) { stopSelf() }, // nút đóng/dừng rõ ràng
            LinearLayout.LayoutParams(dp((38 * scale).toInt()), dp((34 * scale).toInt()))
        )
        p.addView(top)

        val emergency = TextView(this).apply {
            text = "■"
            textSize = 20f * scale
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = Ui.pressable(Ui.DANGER, dp(12).toFloat())
            isClickable = true
            setOnClickListener { MacroEngine.emergencyStop() } // DỪNG KHẨN CẤP ở giữa D-Pad
        }
        val dpad = Ui.dpad(this, cell, emergency) { d ->
            ComboRecorder.record(d)
            if (!MacroEngine.manualSwipe(d)) {
                statusView?.text = if (MacroEngine.status.value.active)
                    "Macro đang chạy — nhấn ■ để dừng" else "Không vuốt được: bật Trợ năng"
            }
        }
        val dpadWrap = LinearLayout(this)
        dpadWrap.gravity = Gravity.CENTER
        dpadWrap.addView(dpad)
        p.addView(dpadWrap, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val m = dp(2)
        row.addView(Ui.button(this, "▶ Chạy", Ui.ACCENT, Ui.ON_ACCENT) { startWorkingMacro() },
            LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { setMargins(m, m, m, m) })
        row.addView(Ui.button(this, "■ Dừng") { MacroEngine.stop() },
            LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { setMargins(m, m, m, m) })
        p.addView(row)

        val rec = Ui.button(this, "● Ghi") {
            if (ComboRecorder.state.value.recording) ComboRecorder.stop() else ComboRecorder.start()
        }
        recBtn = rec
        p.addView(rec, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { setMargins(m, m, m, m) })

        p.visibility = if (panelOpen) View.VISIBLE else View.GONE
        panel = p
        container.addView(p, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP))

        val pos = SettingsRepository.overlayPos() ?: (dp(12) to dp(180))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = pos.first
        lp.y = pos.second
        params = lp
        root = container
        try {
            wm.addView(container, lp)
            container.post { clampAndApply() }
        } catch (e: Exception) {
            // thiếu quyền / bị hệ thống từ chối
            root = null
            stopSelf()
        }
    }

    private fun startWorkingMacro() {
        val macro = PresetRepository.loadWorking()
        statusView?.text = when (MacroEngine.start(macro)) {
            MacroEngine.StartResult.OK -> MacroEngine.describe(MacroEngine.status.value)
            MacroEngine.StartResult.EMPTY -> "Macro trống — tạo trong app"
            MacroEngine.StartResult.NO_SERVICE -> "Chưa bật Trợ năng"
            MacroEngine.StartResult.BUSY -> "Macro đang chạy"
        }
    }

    private fun togglePanel() {
        panelOpen = !panelOpen
        panel?.visibility = if (panelOpen) View.VISIBLE else View.GONE
        root?.let { r ->
            r.post { clampAndApply() }
        }
    }

    private fun clampAndApply() {
        val r = root ?: return
        val lp = params ?: return
        val (sw, sh) = Device.screenSize(this)
        lp.x = lp.x.coerceIn(0, maxOf(0, sw - r.width))
        lp.y = lp.y.coerceIn(0, maxOf(0, sh - r.height))
        try {
            wm.updateViewLayout(r, lp)
        } catch (_: IllegalArgumentException) {
        }
    }

    /** Kéo cửa sổ nổi; chạm nhẹ (không kéo) gọi [onClick]. */
    private inner class DragListener(private val onClick: (() -> Unit)?) : View.OnTouchListener {
        private val slop = ViewConfiguration.get(this@FloatingService).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val lp = params ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        clampAndApply()
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) SettingsRepository.saveOverlayPos(lp.x, lp.y) else onClick?.invoke()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> return true
            }
            return false
        }
    }
}
