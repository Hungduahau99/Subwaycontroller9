package com.subway.controller

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsRepository.init(this)
        PresetRepository.init(this)
    }
}
