package com.subway.controller.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.subway.controller.FloatingService
import com.subway.controller.MacroEngine
import com.subway.controller.util.Device
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class ControllerPage(private val act: Activity) : Page {
    override val title = "Điều khiển"
    override val view: View

    private val overlayStatus: TextView
    private val a11yStatus: TextView
    private val floatBtn: TextView
    private val macroStatus: TextView
    private val progress: ProgressBar

    init {
        val (sv, c) = scrollPage(act)
        view = sv

        c.addView(Ui.text(act, "Subway Controller", 24f, Ui.TEXT, true))
        c.addView(Ui.muted(act, "Bảng điều khiển nổi để vuốt trong Subway Surfers (D-Pad + macro combo)."))
        c.addView(Ui.text(act, "", 8f))

        // --- Bộ điều khiển nổi ---
        val ctl = Ui.card(act)
        ctl.addView(Ui.heading(act, "Bộ điều khiển nổi"))
        floatBtn = Ui.primaryButton(act, "Bật bộ điều khiển nổi") { toggleFloating() }
        ctl.addView(floatBtn, Ui.lp())
        ctl.addView(Ui.text(act, "", 6f))
        macroStatus = Ui.text(act, MacroEngine.describe(MacroEngine.status.value), 14f, Ui.TEXT)
        ctl.addView(macroStatus)
        progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        ctl.addView(progress, Ui.lp(h = act.dp(8)))
        ctl.addView(Ui.text(act, "", 6f))
        ctl.addView(Ui.dangerButton(act, "⛔ DỪNG KHẨN CẤP") { MacroEngine.emergencyStop() }, Ui.lp())
        c.addView(ctl)

        // --- Quyền ---
        val perm = Ui.card(act)
        perm.addView(Ui.heading(act, "Quyền cần thiết"))

        overlayStatus = Ui.text(act, "", 15f, Ui.TEXT, true)
        perm.addView(overlayStatus)
        perm.addView(Ui.muted(act,
            "Quyền “Hiển thị trên ứng dụng khác” để vẽ nút điều khiển nổi phía trên game."))
        perm.addView(Ui.button(act, "Mở cài đặt quyền hiển thị") {
            act.startActivity(Device.overlaySettingsIntent(act))
        }, Ui.lp(margin = act.dp(0)).apply { topMargin = act.dp(8); bottomMargin = act.dp(14) })

        a11yStatus = Ui.text(act, "", 15f, Ui.TEXT, true)
        perm.addView(a11yStatus)
        perm.addView(Ui.muted(act,
            "Dịch vụ Trợ năng chỉ dùng để thực hiện các cú vuốt bạn yêu cầu (dispatchGesture). " +
                "Ứng dụng không đọc, không chụp, không lưu nội dung màn hình. " +
                "Bạn phải tự bật trong Cài đặt."))
        perm.addView(Ui.button(act, "Mở cài đặt Trợ năng") {
            act.startActivity(Device.accessibilitySettingsIntent())
        }, Ui.lp().apply { topMargin = act.dp(8) })
        perm.addView(Ui.text(act, "", 6f))
        perm.addView(Ui.muted(act,
            "Android 13+: nếu mục Subway Controller bị mờ, vào Cài đặt › Ứng dụng › Subway Controller › " +
                "⋮ › “Cho phép cài đặt bị hạn chế”, rồi quay lại bật dịch vụ."))
        c.addView(perm)

        // --- Lưu ý ---
        val note = Ui.card(act)
        note.addView(Ui.heading(act, "Lưu ý"))
        note.addView(Ui.muted(act,
            "• Cú vuốt được gửi tới tọa độ trên màn hình game (xem tab Cài đặt để hiệu chỉnh). " +
                "Đừng đặt bảng điều khiển nổi che điểm bắt đầu vuốt.\n" +
                "• Kết quả có thể khác nhau tuỳ phiên bản Android và cách game xử lý cảm ứng.\n" +
                "• Ứng dụng không tác động tới cơ chế chống gian lận của game hay các biện pháp bảo vệ của Android."))
        c.addView(note)

        refresh()
    }

    override fun refresh() {
        val overlayOk = Device.canDrawOverlays(act)
        overlayStatus.text = if (overlayOk) "✅ Quyền hiển thị: đã cấp" else "❌ Quyền hiển thị: chưa cấp"
        overlayStatus.setTextColor(if (overlayOk) Ui.ACCENT else Ui.WARN)

        val connected = com.subway.controller.GestureAccessibilityService.instance != null
        val enabled = Device.isAccessibilityEnabled(act)
        a11yStatus.text = when {
            connected -> "✅ Dịch vụ Trợ năng: đang chạy"
            enabled -> "⏳ Dịch vụ Trợ năng: đã bật, đang kết nối…"
            else -> "❌ Dịch vụ Trợ năng: chưa bật"
        }
        a11yStatus.setTextColor(if (connected) Ui.ACCENT else Ui.WARN)
    }

    override fun bind(scope: CoroutineScope) {
        scope.launch {
            FloatingService.running.collect { running ->
                floatBtn.text = if (running) "Tắt bộ điều khiển nổi" else "Bật bộ điều khiển nổi"
            }
        }
        scope.launch {
            MacroEngine.status.collect { st ->
                macroStatus.text = MacroEngine.describe(st)
                progress.max = if (st.total > 0) st.total else 1
                progress.progress = st.index
            }
        }
    }

    private fun toggleFloating() {
        if (FloatingService.running.value) {
            act.stopService(Intent(act, FloatingService::class.java))
            return
        }
        if (!Device.canDrawOverlays(act)) {
            Ui.toast(act, "Cần cấp quyền hiển thị trên ứng dụng khác trước")
            act.startActivity(Device.overlaySettingsIntent(act))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            // Không bắt buộc: bị từ chối vẫn chạy được, chỉ không thấy thông báo.
            act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (com.subway.controller.GestureAccessibilityService.instance == null) {
            Ui.toast(act, "Lưu ý: chưa bật Trợ năng, các nút sẽ chưa vuốt được")
        }
        try {
            act.startForegroundService(Intent(act, FloatingService::class.java))
        } catch (e: Exception) {
            Ui.toast(act, "Không thể khởi động: ${e.message}")
        }
    }
}
