package com.subway.controller.ui

import android.app.Activity
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import com.subway.controller.MacroEngine
import com.subway.controller.PresetRepository
import com.subway.controller.SettingsRepository
import com.subway.controller.models.Direction
import com.subway.controller.models.Limits
import com.subway.controller.models.Macro
import com.subway.controller.models.MacroAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.UUID

class EditorPage(private val act: Activity) : Page {
    override val title = "Macro"
    override val view: View

    private var macro: Macro = PresetRepository.loadWorking()

    private val list: LinearLayout
    private val nameField: EditText
    private val repeatField: EditText
    private val infiniteSwitch: Switch
    private val statusText: TextView
    private val progress: ProgressBar
    private val pauseBtn: TextView
    private val summaryText: TextView
    private var loading = false

    private fun update(m: Macro) {
        macro = m
        PresetRepository.saveWorking(m)
        summaryText.text = summary()
    }

    private fun summary(): String {
        val secs = macro.estimatedLoopMs() / 1000.0
        return "${macro.actions.size} hành động • ~${"%.1f".format(secs)}s / vòng"
    }

    init {
        val (sv, c) = scrollPage(act)
        view = sv

        c.addView(Ui.text(act, "Macro Editor", 22f, Ui.TEXT, true))
        c.addView(Ui.muted(act, "Đây là macro đang dùng: nút ▶ trên bảng điều khiển nổi sẽ chạy macro này."))
        c.addView(Ui.text(act, "", 6f))

        // --- Tên + lặp ---
        val info = Ui.card(act)
        nameField = EditText(act).apply {
            setSingleLine()
            setTextColor(Ui.TEXT)
            hint = "Tên macro"
            setHintTextColor(Ui.MUTED)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (loading) return
                    update(macro.copy(name = s?.toString().orEmpty().take(60).ifBlank { "Macro" }))
                }
            })
        }
        info.addView(nameField, Ui.lp())

        val repRow = Ui.row(act)
        repRow.addView(Ui.text(act, "Số vòng lặp:"), Ui.lp(Ui.WRAP, Ui.WRAP))
        repeatField = Ui.numberField(act, macro.repeat, Limits.REPEAT_MIN, Limits.REPEAT_MAX) {
            if (!loading) update(macro.copy(repeat = it))
        }
        repRow.addView(repeatField, Ui.lp(act.dp(90), Ui.WRAP, margin = act.dp(6)))
        infiniteSwitch = Switch(act).apply {
            text = "Lặp vô hạn"
            setTextColor(Ui.TEXT)
            setOnCheckedChangeListener { _, checked ->
                if (!loading) update(macro.copy(infinite = checked))
            }
        }
        repRow.addView(infiniteSwitch, Ui.lp(0, Ui.WRAP, 1f))
        info.addView(repRow, Ui.lp())
        summaryText = Ui.muted(act, "")
        info.addView(summaryText)
        c.addView(info)

        // --- Thêm hành động ---
        val add = Ui.card(act)
        add.addView(Ui.heading(act, "Thêm hành động"))
        val addRow = Ui.row(act)
        for (d in Direction.values()) {
            addRow.addView(Ui.button(act, d.arrow + " " + d.label) { addAction(d) },
                Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        }
        add.addView(addRow, Ui.lp())
        add.addView(Ui.text(act, "", 6f))

        val allDelay = Ui.row(act)
        var delayAll = SettingsRepository.load().delayMs
        allDelay.addView(Ui.text(act, "Trễ mọi bước (ms):"), Ui.lp(0, Ui.WRAP, 1f))
        allDelay.addView(Ui.numberField(act, delayAll, Limits.DELAY_MIN, Limits.DELAY_MAX) { delayAll = it },
            Ui.lp(act.dp(90), Ui.WRAP, margin = act.dp(4)))
        allDelay.addView(Ui.smallButton(act, "Áp dụng") {
            update(macro.copy(actions = macro.actions.map { it.copy(delayMs = delayAll) }))
            renderList()
        })
        add.addView(allDelay, Ui.lp())

        val allDur = Ui.row(act)
        var durAll = SettingsRepository.load().durationMs
        allDur.addView(Ui.text(act, "Thời lượng vuốt mọi bước (ms):"), Ui.lp(0, Ui.WRAP, 1f))
        allDur.addView(Ui.numberField(act, durAll, Limits.DURATION_MIN, Limits.DURATION_MAX) { durAll = it },
            Ui.lp(act.dp(90), Ui.WRAP, margin = act.dp(4)))
        allDur.addView(Ui.smallButton(act, "Áp dụng") {
            update(macro.copy(actions = macro.actions.map { it.copy(durationMs = durAll) }))
            renderList()
        })
        add.addView(allDur, Ui.lp())
        c.addView(add)

        // --- Danh sách ---
        val seq = Ui.card(act)
        val head = Ui.row(act)
        head.addView(Ui.heading(act, "Chuỗi hành động"), Ui.lp(0, Ui.WRAP, 1f))
        head.addView(Ui.smallButton(act, "Xóa hết") {
            Ui.confirm(act, "Xóa toàn bộ hành động?") {
                update(macro.copy(actions = emptyList()))
                renderList()
            }
        })
        seq.addView(head, Ui.lp())
        list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        seq.addView(list, Ui.lp())
        c.addView(seq)

        // --- Chạy ---
        val run = Ui.card(act)
        run.addView(Ui.heading(act, "Chạy macro"))
        statusText = Ui.text(act, MacroEngine.describe(MacroEngine.status.value))
        run.addView(statusText)
        progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        run.addView(progress, Ui.lp(h = act.dp(8)))
        run.addView(Ui.text(act, "", 6f))

        val r1 = Ui.row(act)
        r1.addView(Ui.primaryButton(act, "▶ Chạy") { startMacro(0L) }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        pauseBtn = Ui.button(act, "⏸ Tạm dừng") {
            if (MacroEngine.status.value.state == MacroEngine.State.PAUSED) MacroEngine.resume()
            else MacroEngine.pause()
        }
        r1.addView(pauseBtn, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        r1.addView(Ui.button(act, "■ Dừng") { MacroEngine.stop() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        run.addView(r1, Ui.lp())

        run.addView(Ui.button(act, "▶ Chạy sau 5 giây (kịp chuyển sang game)") { startMacro(5000L) },
            Ui.lp(margin = act.dp(2)))
        run.addView(Ui.dangerButton(act, "⛔ DỪNG KHẨN CẤP") { MacroEngine.emergencyStop() },
            Ui.lp(margin = act.dp(2)))
        run.addView(Ui.muted(act,
            "Cú vuốt gửi tới màn hình đang hiển thị. Nếu bấm Chạy ngay trong app này, macro sẽ vuốt lên chính app. " +
                "Hãy dùng nút ▶ trên bảng điều khiển nổi khi đang ở trong game, hoặc “Chạy sau 5 giây”."))
        c.addView(run)

        // --- Lưu / mới ---
        val file = Ui.card(act)
        val fr = Ui.row(act)
        fr.addView(Ui.primaryButton(act, "Lưu vào Preset") { saveAsPreset() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        fr.addView(Ui.button(act, "Macro mới") {
            Ui.confirm(act, "Bỏ macro hiện tại và tạo macro trống?") {
                update(Macro())
                refresh()
            }
        }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        file.addView(fr, Ui.lp())
        c.addView(file)

        refresh()
    }

    override fun refresh() {
        loading = true
        macro = PresetRepository.loadWorking()
        nameField.setText(macro.name)
        repeatField.setText(macro.repeat.toString())
        infiniteSwitch.isChecked = macro.infinite
        loading = false
        summaryText.text = summary()
        renderList()
    }

    override fun bind(scope: CoroutineScope) {
        scope.launch {
            MacroEngine.status.collect { st ->
                statusText.text = MacroEngine.describe(st)
                progress.max = if (st.total > 0) st.total else 1
                progress.progress = st.index
                pauseBtn.text = if (st.state == MacroEngine.State.PAUSED) "▶ Tiếp tục" else "⏸ Tạm dừng"
            }
        }
    }

    private fun addAction(d: Direction) {
        if (macro.actions.size >= Limits.MAX_ACTIONS) {
            Ui.toast(act, "Tối đa ${Limits.MAX_ACTIONS} hành động")
            return
        }
        val s = SettingsRepository.load()
        update(macro.copy(actions = macro.actions + MacroAction(d, s.delayMs, s.durationMs)))
        renderList()
    }

    private fun startMacro(delayMs: Long) {
        when (MacroEngine.start(macro, delayMs)) {
            MacroEngine.StartResult.OK -> {}
            MacroEngine.StartResult.EMPTY -> Ui.toast(act, "Macro chưa có hành động nào")
            MacroEngine.StartResult.NO_SERVICE -> Ui.toast(act, "Chưa bật dịch vụ Trợ năng (tab Điều khiển)")
            MacroEngine.StartResult.BUSY -> Ui.toast(act, "Một macro đang chạy — hãy dừng trước")
        }
    }

    private fun saveAsPreset() {
        val existing = PresetRepository.all().firstOrNull { it.name.equals(macro.name, ignoreCase = true) }
        val toSave = macro.copy(id = existing?.id ?: UUID.randomUUID().toString())
        PresetRepository.save(toSave)
        Ui.toast(act, if (existing != null) "Đã cập nhật preset “${toSave.name}”" else "Đã lưu preset “${toSave.name}”")
    }

    private fun mutate(i: Int, f: (MacroAction) -> MacroAction) {
        if (i !in macro.actions.indices) return
        val l = macro.actions.toMutableList()
        l[i] = f(l[i])
        update(macro.copy(actions = l))
    }

    private fun move(i: Int, to: Int) {
        if (i !in macro.actions.indices || to !in macro.actions.indices) return
        val l = macro.actions.toMutableList()
        val item = l.removeAt(i)
        l.add(to, item)
        update(macro.copy(actions = l))
        renderList()
    }

    private fun remove(i: Int) {
        if (i !in macro.actions.indices) return
        val l = macro.actions.toMutableList()
        l.removeAt(i)
        update(macro.copy(actions = l))
        renderList()
    }

    private fun renderList() {
        list.removeAllViews()
        if (macro.actions.isEmpty()) {
            list.addView(Ui.muted(act, "Chưa có hành động. Bấm ↑ ↓ ← → ở trên để thêm, hoặc dùng Combo Recorder."))
            return
        }
        macro.actions.forEachIndexed { i, a ->
            val box = LinearLayout(act)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(act.dp(10), act.dp(8), act.dp(10), act.dp(8))
            box.background = Ui.rounded(Ui.SURFACE2, act.dp(10).toFloat())

            val top = Ui.row(act)
            top.addView(Ui.text(act, "${i + 1}.  ${a.direction.arrow}  ${a.direction.label}", 16f, Ui.TEXT, true),
                Ui.lp(0, Ui.WRAP, 1f))
            top.addView(Ui.smallButton(act, "▲", Ui.SURFACE) { move(i, i - 1) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, act.dp(2)))
            top.addView(Ui.smallButton(act, "▼", Ui.SURFACE) { move(i, i + 1) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, act.dp(2)))
            top.addView(Ui.smallButton(act, "✕", Ui.DANGER) { remove(i) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, act.dp(2)))
            box.addView(top, Ui.lp())

            val bottom = Ui.row(act)
            bottom.addView(Ui.muted(act, "Vuốt (ms)"), Ui.lp(Ui.WRAP, Ui.WRAP))
            bottom.addView(
                Ui.numberField(act, a.durationMs, Limits.DURATION_MIN, Limits.DURATION_MAX) { v ->
                    mutate(i) { it.copy(durationMs = v) }
                }, Ui.lp(act.dp(80), Ui.WRAP, margin = act.dp(4))
            )
            bottom.addView(Ui.muted(act, "Trễ sau (ms)"), Ui.lp(Ui.WRAP, Ui.WRAP))
            bottom.addView(
                Ui.numberField(act, a.delayMs, Limits.DELAY_MIN, Limits.DELAY_MAX) { v ->
                    mutate(i) { it.copy(delayMs = v) }
                }, Ui.lp(act.dp(80), Ui.WRAP, margin = act.dp(4))
            )
            box.addView(bottom, Ui.lp())

            list.addView(box, Ui.lp(margin = act.dp(3)))
        }
    }
}
