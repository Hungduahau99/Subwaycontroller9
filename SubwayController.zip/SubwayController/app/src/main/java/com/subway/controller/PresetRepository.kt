package com.subway.controller

import android.content.Context
import android.content.SharedPreferences
import com.subway.controller.models.Macro
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.UUID

/**
 * Lưu preset cục bộ dạng JSON có phiên bản:
 * {"version":1,"presets":[{id,name,repeat,infinite,actions:[{d,delay,dur}]}]}
 * Dữ liệu cũ (mảng JSON trần) hoặc hỏng sẽ không làm app crash; bản hỏng được sao lưu lại.
 */
object PresetRepository {
    private const val VERSION = 1
    private const val KEY_PRESETS = "presets"
    private const val KEY_WORKING = "working"
    private const val KEY_BACKUP = "presets_corrupt_backup"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("presets_v1", Context.MODE_PRIVATE)
    }

    @Synchronized
    fun all(): List<Macro> = parse(readString(KEY_PRESETS))

    @Synchronized
    fun save(m: Macro) {
        val list = all().toMutableList()
        val i = list.indexOfFirst { it.id == m.id }
        if (i >= 0) list[i] = m else list.add(m)
        write(list)
    }

    @Synchronized
    fun delete(id: String) = write(all().filterNot { it.id == id })

    @Synchronized
    fun rename(id: String, name: String) =
        write(all().map { if (it.id == id) it.copy(name = name.take(60)) else it })

    @Synchronized
    fun duplicate(id: String): Macro? {
        val src = all().firstOrNull { it.id == id } ?: return null
        val copy = src.copy(id = UUID.randomUUID().toString(), name = (src.name + " (bản sao)").take(60))
        write(all() + copy)
        return copy
    }

    /** Macro đang soạn; bảng điều khiển nổi sẽ chạy macro này. */
    @Synchronized
    fun loadWorking(): Macro {
        val raw = readString(KEY_WORKING) ?: return Macro()
        return try { Macro.fromJson(JSONObject(raw)) } catch (e: JSONException) { Macro() }
    }

    @Synchronized
    fun saveWorking(m: Macro) {
        prefs.edit().putString(KEY_WORKING, m.toJson().toString()).apply()
    }

    private fun readString(key: String): String? =
        try { prefs.getString(key, null) } catch (e: ClassCastException) { null }

    private fun write(list: List<Macro>) {
        val root = JSONObject()
            .put("version", VERSION)
            .put("presets", JSONArray().also { arr -> list.forEach { arr.put(it.toJson()) } })
        prefs.edit().putString(KEY_PRESETS, root.toString()).apply()
    }

    internal fun parse(raw: String?): List<Macro> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val t = raw.trim()
            val arr: JSONArray = if (t.startsWith("[")) {
                JSONArray(t) // định dạng cũ (v0): mảng trần
            } else {
                JSONObject(t).optJSONArray("presets") ?: JSONArray()
            }
            val out = ArrayList<Macro>()
            for (i in 0 until arr.length()) {
                arr.optJSONObject(i)?.let { out.add(Macro.fromJson(it)) }
            }
            out
        } catch (e: JSONException) {
            if (this::prefs.isInitialized) prefs.edit().putString(KEY_BACKUP, raw).apply()
            emptyList()
        }
    }
}
