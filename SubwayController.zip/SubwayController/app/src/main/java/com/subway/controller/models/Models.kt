package com.subway.controller.models

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object Limits {
    const val DELAY_MIN = 0
    const val DELAY_MAX = 3000
    const val DELAY_DEFAULT = 100
    const val DURATION_MIN = 50
    const val DURATION_MAX = 1000
    const val DURATION_DEFAULT = 100
    const val REPEAT_MIN = 1
    const val REPEAT_MAX = 9999
    const val MAX_ACTIONS = 500
}

enum class Direction(val arrow: String, val label: String) {
    UP("↑", "Lên"),
    DOWN("↓", "Xuống"),
    LEFT("←", "Trái"),
    RIGHT("→", "Phải")
}

data class MacroAction(
    val direction: Direction,
    /** Thời gian chờ SAU khi vuốt xong, trước hành động kế tiếp. */
    val delayMs: Int = Limits.DELAY_DEFAULT,
    val durationMs: Int = Limits.DURATION_DEFAULT
) {
    fun toJson(): JSONObject = JSONObject()
        .put("d", direction.name)
        .put("delay", delayMs)
        .put("dur", durationMs)

    companion object {
        fun fromJson(o: JSONObject): MacroAction? {
            val dir = runCatching { Direction.valueOf(o.optString("d")) }.getOrNull() ?: return null
            return MacroAction(
                dir,
                o.optInt("delay", Limits.DELAY_DEFAULT).coerceIn(Limits.DELAY_MIN, Limits.DELAY_MAX),
                o.optInt("dur", Limits.DURATION_DEFAULT).coerceIn(Limits.DURATION_MIN, Limits.DURATION_MAX)
            )
        }
    }
}

data class Macro(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Macro mới",
    val actions: List<MacroAction> = emptyList(),
    val repeat: Int = 1,
    val infinite: Boolean = false
) {
    fun summary(): String = actions.joinToString(" ") { it.direction.arrow }

    /** Thời gian ước tính của một vòng (ms). */
    fun estimatedLoopMs(): Long = actions.sumOf { (it.durationMs + it.delayMs).toLong() }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("repeat", repeat)
        .put("infinite", infinite)
        .put("actions", JSONArray().also { arr -> actions.forEach { arr.put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): Macro {
            val arr = o.optJSONArray("actions") ?: JSONArray()
            val list = ArrayList<MacroAction>()
            for (i in 0 until minOf(arr.length(), Limits.MAX_ACTIONS)) {
                val item = arr.optJSONObject(i) ?: continue
                MacroAction.fromJson(item)?.let { list.add(it) }
            }
            return Macro(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                name = o.optString("name").ifBlank { "Macro" }.take(60),
                actions = list,
                repeat = o.optInt("repeat", 1).coerceIn(Limits.REPEAT_MIN, Limits.REPEAT_MAX),
                infinite = o.optBoolean("infinite", false)
            )
        }
    }
}

data class AppSettings(
    val delayMs: Int = Limits.DELAY_DEFAULT,
    val durationMs: Int = Limits.DURATION_DEFAULT,
    /** Điểm bắt đầu vuốt, tính theo % kích thước màn hình (an toàn khi xoay/đổi độ phân giải). */
    val startXPct: Int = 50,
    val startYPct: Int = 65,
    /** Quãng vuốt, % của chiều rộng (trái/phải) hoặc chiều cao (lên/xuống). */
    val distancePct: Int = 18,
    val overlayAlphaPct: Int = 85,
    val overlaySizePct: Int = 100
) {
    fun sanitized() = AppSettings(
        delayMs.coerceIn(Limits.DELAY_MIN, Limits.DELAY_MAX),
        durationMs.coerceIn(Limits.DURATION_MIN, Limits.DURATION_MAX),
        startXPct.coerceIn(0, 100),
        startYPct.coerceIn(0, 100),
        distancePct.coerceIn(5, 60),
        overlayAlphaPct.coerceIn(20, 100),
        overlaySizePct.coerceIn(60, 160)
    )
}
