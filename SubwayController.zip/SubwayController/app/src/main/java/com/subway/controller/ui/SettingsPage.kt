package com.subway.controller.ui

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.subway.controller.MacroEngine
import com.subway.controller.SettingsRepository
import com.subway.controller.models.Direction
import com.subway.controller.models.Limits
import com.subway.controller.util.Device

class SettingsPage(private val act: Activity) : Page {
    override val title = "Cài đặt"
    override val view: View
    private val content: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var screenInfo: TextView

    init {
        val (sv, c) = scrollPage(act)
        view = sv
        content = c
        build()
    }

    override fun refresh() {
        if (this::screenInfo.isInitialized) screenInfo.text = screenText()
    }

    private fun screenText(): String {
        val (w, h) = Device.screenSize(act)
        val s = SettingsRepository.load()
        val x = (w * s.startXPct / 100f).toInt()
        val y = (h * s.startYPct / 100f).toInt()
        return "Màn hình hiện tại: $w × $h px • điểm bắt đầu ≈ ($x, $y) px"
    }

    private fun build() {
        content.removeAllViews()
        val s = SettingsRepository.load()
        var cur = s

        fun change(f: (com.subway.controller.models.AppSettings) -> com.subway.controller.models.AppSettings) {
            cur = f(cur).sanitized()
            SettingsRepository.save(cur)
            if (this::screenInfo.isInitialized) screenInfo.text = screenText()
        }

        content.addView(Ui.text(act, "Cài đặt & hiệu chỉnh", 22f, Ui.TEXT, true))
        content.addView(Ui.text(act, "", 6f))

        val timing = Ui.card(act)
        timing.addView(Ui.heading(act, "Thời gian"))
        timing.addView(Ui.slider(act, "Trễ mặc định", Limits.DELAY_MIN, Limits.DELAY_MAX, s.delayMs, " ms") { v ->
            change { it.copy(delayMs = v) }
        })
        timing.addView(Ui.slider(act, "Thời lượng vuốt mặc định", Limits.DURATION_MIN, Limits.DURATION_MAX, s.durationMs, " ms") { v ->
            change { it.copy(durationMs = v) }
        })
        content.addView(timing)

        val cal = Ui.card(act)
        cal.addView(Ui.heading(act, "Hiệu chỉnh cú vuốt"))
        cal.addView(Ui.muted(act,
            "Tọa độ tính theo % màn hình nên vẫn đúng khi xoay máy hoặc đổi độ phân giải. " +
                "Hãy đặt điểm bắt đầu vào giữa khu vực chơi của game."))
        screenInfo = Ui.text(act, screenText(), 13f, Ui.ACCENT)
        cal.addView(screenInfo)
        cal.addView(Ui.slider(act, "Điểm bắt đầu X", 0, 100, s.startXPct, " %") { v -> change { it.copy(startXPct = v) } })
        cal.addView(Ui.slider(act, "Điểm bắt đầu Y", 0, 100, s.startYPct, " %") { v -> change { it.copy(startYPct = v) } })
        cal.addView(Ui.slider(act, "Quãng vuốt", 5, 60, s.distancePct, " %") { v -> change { it.copy(distancePct = v) } })
        content.addView(cal)

        val test = Ui.card(act)
        test.addView(Ui.heading(act, "Thử & kiểm tra"))
        test.addView(Ui.muted(act,
            "1) “Hiện điểm vuốt” vẽ điểm bắt đầu (xanh) và điểm kết thúc 4 hướng (cam) trong 6 giây — " +
                "chuyển sang game để đối chiếu.\n" +
                "2) Nếu bảng điều khiển nổi che điểm bắt đầu, hãy kéo nó sang chỗ khác hoặc thu nhỏ/ẩn nó, " +
                "vì cú vuốt không được gửi vào chính bảng điều khiển.\n" +
                "3) Các nút thử bên dưới vuốt sau 4 giây để bạn kịp chuyển sang game."))
        test.addView(Ui.button(act, "Hiện điểm vuốt (6 giây)") {
            if (!CalibrationOverlay.show(act)) Ui.toast(act, "Cần quyền hiển thị trên ứng dụng khác")
        }, Ui.lp().apply { topMargin = act.dp(8); bottomMargin = act.dp(4) })
        val tr = Ui.row(act)
        for (d in Direction.values()) {
            tr.addView(Ui.button(act, d.arrow) { testSwipe(d) }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        }
        test.addView(tr, Ui.lp())
        content.addView(test)

        val ov = Ui.card(act)
        ov.addView(Ui.heading(act, "Bảng điều khiển nổi"))
        ov.addView(Ui.slider(act, "Độ trong suốt", 20, 100, s.overlayAlphaPct, " %") { v -> change { it.copy(overlayAlphaPct = v) } })
        ov.addView(Ui.slider(act, "Kích thước", 60, 160, s.overlaySizePct, " %") { v -> change { it.copy(overlaySizePct = v) } })
        content.addView(ov)

        content.addView(Ui.button(act, "Khôi phục mặc định") {
            Ui.confirm(act, "Khôi phục toàn bộ cài đặt về mặc định?") {
                SettingsRepository.reset()
                build()
            }
        }, Ui.lp())
    }

    private fun testSwipe(d: Direction) {
        if (MacroEngine.status.value.active) {
            Ui.toast(act, "Macro đang chạy")
            return
        }
        Ui.toast(act, "Vuốt ${d.label} sau 4 giây — hãy chuyển sang game")
        handler.postDelayed({
            if (!MacroEngine.manualSwipe(d)) Ui.toast(act, "Không gửi được: kiểm tra dịch vụ Trợ năng")
        }, 4000L)
    }
}
