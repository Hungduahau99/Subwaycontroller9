package com.subway.controller.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.subway.controller.models.Direction

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

object Ui {
    val BG = Color.parseColor("#121212")
    val SURFACE = Color.parseColor("#1F1F1F")
    val SURFACE2 = Color.parseColor("#2E2E2E")
    val TEXT = Color.parseColor("#ECECEC")
    val MUTED = Color.parseColor("#A3A8AE")
    val ACCENT = Color.parseColor("#3DDC84")
    val DANGER = Color.parseColor("#D93A3F")
    val WARN = Color.parseColor("#F5A623")
    val ON_ACCENT = Color.parseColor("#06210F")

    const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    fun rounded(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
        }

    private fun lighten(c: Int): Int {
        fun mix(x: Int) = (x + (255 - x) * 0.30f).toInt().coerceIn(0, 255)
        return Color.rgb(mix(Color.red(c)), mix(Color.green(c)), mix(Color.blue(c)))
    }

    /** Nền có phản hồi khi nhấn (sáng lên). */
    fun pressable(color: Int, radiusPx: Float): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), rounded(lighten(color), radiusPx))
        addState(intArrayOf(), rounded(color, radiusPx))
    }

    fun lp(w: Int = MATCH, h: Int = WRAP, weight: Float = 0f, margin: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(margin, margin, margin, margin) }

    fun text(ctx: Context, s: String, sp: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun heading(ctx: Context, s: String): TextView = text(ctx, s, 17f, ACCENT, true).apply {
        setPadding(0, ctx.dp(4), 0, ctx.dp(6))
    }

    fun muted(ctx: Context, s: String): TextView = text(ctx, s, 13f, MUTED)

    /** Dùng TextView thay Button để không phụ thuộc theme (an toàn trong cửa sổ overlay). */
    fun button(
        ctx: Context,
        label: String,
        color: Int = SURFACE2,
        textColor: Int = TEXT,
        onClick: () -> Unit
    ): TextView = TextView(ctx).apply {
        text = label
        textSize = 15f
        setTextColor(textColor)
        gravity = Gravity.CENTER
        setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
        minHeight = ctx.dp(44)
        background = pressable(color, ctx.dp(10).toFloat())
        isClickable = true
        setOnClickListener { onClick() }
    }

    fun primaryButton(ctx: Context, label: String, onClick: () -> Unit): TextView =
        button(ctx, label, ACCENT, ON_ACCENT, onClick).apply { setTypeface(typeface, Typeface.BOLD) }

    fun dangerButton(ctx: Context, label: String, onClick: () -> Unit): TextView =
        button(ctx, label, DANGER, Color.WHITE, onClick).apply { setTypeface(typeface, Typeface.BOLD) }

    fun smallButton(ctx: Context, label: String, color: Int = SURFACE2, onClick: () -> Unit): TextView =
        button(ctx, label, color, TEXT, onClick).apply {
            minWidth = ctx.dp(40)
            minHeight = ctx.dp(36)
            setPadding(ctx.dp(6), ctx.dp(4), ctx.dp(6), ctx.dp(4))
        }

    fun card(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        background = rounded(SURFACE, ctx.dp(14).toFloat())
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) }
    }

    fun row(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    /** Ô nhập số: luôn giữ giá trị hợp lệ (đã kẹp) trong mô hình, kể cả khi đang gõ dở. */
    fun numberField(ctx: Context, initial: Int, lo: Int, hi: Int, onValue: (Int) -> Unit): EditText {
        var current = initial.coerceIn(lo, hi)
        val et = EditText(ctx)
        et.setText(current.toString())
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setSingleLine()
        et.setSelectAllOnFocus(true)
        et.setTextColor(TEXT)
        et.gravity = Gravity.CENTER
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.toIntOrNull() ?: return
                current = v.coerceIn(lo, hi)
                onValue(current)
            }
        })
        et.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) et.setText(current.toString())
        }
        return et
    }

    fun slider(
        ctx: Context, label: String, lo: Int, hi: Int, value: Int, unit: String,
        onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, ctx.dp(4), 0, ctx.dp(4))
        val tv = text(ctx, "$label: $value$unit")
        val sb = SeekBar(ctx)
        sb.max = hi - lo
        sb.progress = value.coerceIn(lo, hi) - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                tv.text = "$label: $v$unit"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    fun prompt(ctx: Context, title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(ctx)
        et.setText(initial)
        et.setSingleLine()
        et.setSelectAllOnFocus(true)
        val frame = FrameLayout(ctx)
        frame.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), 0)
        frame.addView(et)
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(frame)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) onOk(t.take(60))
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    fun confirm(ctx: Context, message: String, onYes: () -> Unit) {
        AlertDialog.Builder(ctx)
            .setMessage(message)
            .setPositiveButton("Đồng ý") { _, _ -> onYes() }
            .setNegativeButton("Hủy", null)
            .show()
    }

    /**
     * D-Pad 4 hướng. [center] là view ở giữa (nút dừng khẩn cấp trên overlay).
     * Nút có phản hồi khi nhấn.
     */
    fun dpad(ctx: Context, cellPx: Int, center: View, onPress: (Direction) -> Unit): LinearLayout {
        val gap = ctx.dp(3)
        fun cellParams() = LinearLayout.LayoutParams(cellPx, cellPx).apply { setMargins(gap, gap, gap, gap) }
        fun blank(): View = View(ctx).apply { layoutParams = cellParams() }
        fun arrowBtn(d: Direction): View = TextView(ctx).apply {
            text = d.arrow
            textSize = (cellPx / ctx.resources.displayMetrics.density) * 0.5f
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            background = pressable(SURFACE2, ctx.dp(12).toFloat())
            isClickable = true
            layoutParams = cellParams()
            setOnClickListener { onPress(d) }
        }
        fun line(a: View, b: View, c: View): LinearLayout = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(a)
            addView(b)
            addView(c)
        }
        center.layoutParams = cellParams()
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(line(blank(), arrowBtn(Direction.UP), blank()))
            addView(line(arrowBtn(Direction.LEFT), center, arrowBtn(Direction.RIGHT)))
            addView(line(blank(), arrowBtn(Direction.DOWN), blank()))
        }
    }
}
