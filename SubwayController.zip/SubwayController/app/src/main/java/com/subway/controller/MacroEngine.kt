package com.subway.controller

import com.subway.controller.models.Direction
import com.subway.controller.models.Macro
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume

/**
 * Hàng đợi thực thi tuần tự:
 *  - chỉ một macro chạy tại một thời điểm;
 *  - mỗi cú vuốt chờ callback hoàn tất rồi mới tới cú kế tiếp (Mutex bảo đảm không chồng dispatchGesture);
 *  - kiểm tra hủy + kiểm tra Accessibility trước MỖI hành động;
 *  - không chạy trên main thread (chỉ dispatchGesture được gọi trên main).
 */
object MacroEngine {
    enum class State { IDLE, COUNTDOWN, RUNNING, PAUSED }

    enum class StartResult { OK, EMPTY, NO_SERVICE, BUSY }

    data class Status(
        val state: State = State.IDLE,
        val name: String = "",
        val index: Int = 0,      // bước hiện tại, bắt đầu từ 1
        val total: Int = 0,
        val loop: Int = 0,       // vòng hiện tại, bắt đầu từ 1
        val loops: Int = 0,      // 0 = vô hạn
        val message: String = "Sẵn sàng"
    ) {
        val active: Boolean get() = state != State.IDLE
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _status = MutableStateFlow(Status())
    val status: StateFlow<Status> = _status.asStateFlow()

    private val gestureMutex = Mutex()
    private val lock = Any()
    private var job: Job? = null
    private var runId = 0
    private val pendingManual = AtomicInteger(0)

    @Volatile
    private var paused = false

    fun describe(s: Status): String = when (s.state) {
        State.IDLE -> s.message
        State.COUNTDOWN -> s.message
        State.RUNNING, State.PAUSED -> {
            val loopText = if (s.loops == 0) "vòng ${s.loop}/∞" else "vòng ${s.loop}/${s.loops}"
            val prefix = if (s.state == State.PAUSED) "⏸ Tạm dừng" else "▶ Đang chạy"
            "$prefix: ${s.name} — bước ${s.index}/${s.total}, $loopText"
        }
    }

    fun start(macro: Macro, startDelayMs: Long = 0L): StartResult {
        if (macro.actions.isEmpty()) return StartResult.EMPTY
        if (GestureAccessibilityService.instance == null) return StartResult.NO_SERVICE
        synchronized(lock) {
            if (job?.isActive == true) return StartResult.BUSY
            val id = ++runId
            paused = false
            _status.value = Status(
                state = if (startDelayMs > 0) State.COUNTDOWN else State.RUNNING,
                name = macro.name, total = macro.actions.size,
                loops = if (macro.infinite) 0 else macro.repeat,
                message = "Đang khởi động…"
            )
            job = scope.launch { execute(id, macro, startDelayMs) }
        }
        return StartResult.OK
    }

    fun pause() {
        synchronized(lock) {
            if (_status.value.state == State.RUNNING) {
                paused = true
                _status.value = _status.value.copy(state = State.PAUSED)
            }
        }
    }

    fun resume() {
        synchronized(lock) {
            if (_status.value.state == State.PAUSED) {
                paused = false
                _status.value = _status.value.copy(state = State.RUNNING)
            }
        }
    }

    /** Hủy ngay mọi việc đang chờ; không có cú vuốt mới nào được gửi sau khi hàm này trả về. */
    fun stop(message: String = "Đã dừng") {
        synchronized(lock) {
            runId++ // vô hiệu hóa mọi cập nhật trạng thái muộn từ lần chạy cũ
            job?.cancel()
            job = null
            paused = false
            _status.value = Status(message = message)
        }
    }

    fun emergencyStop() = stop("⛔ DỪNG KHẨN CẤP")

    fun onServiceLost() {
        if (_status.value.active) stop("Accessibility bị ngắt — macro đã dừng. Hãy bật lại dịch vụ.")
    }

    /** Một cú vuốt đơn lẻ từ D-Pad. Trả về false nếu không thể gửi. */
    fun manualSwipe(direction: Direction): Boolean {
        val svc = GestureAccessibilityService.instance ?: return false
        if (_status.value.active) return false // đang chạy macro: bỏ qua thao tác tay
        if (pendingManual.get() >= 4) return true // chống dồn hàng đợi khi bấm quá nhanh
        pendingManual.incrementAndGet()
        scope.launch {
            try {
                swipeAwait(svc, direction, SettingsRepository.load().durationMs)
            } finally {
                pendingManual.decrementAndGet()
            }
        }
        return true
    }

    private inline fun publish(id: Int, build: () -> Status) {
        synchronized(lock) { if (runId == id) _status.value = build() }
    }

    private suspend fun execute(id: Int, macro: Macro, startDelayMs: Long) {
        val total = macro.actions.size
        val loops = if (macro.infinite) 0 else macro.repeat
        var endMessage = "✅ Hoàn tất"
        try {
            var remaining = startDelayMs
            while (remaining > 0) {
                val secs = (remaining + 999) / 1000
                publish(id) {
                    Status(State.COUNTDOWN, macro.name, 0, total, 0, loops,
                        "Bắt đầu sau ${secs}s — hãy chuyển sang game")
                }
                val step = minOf(remaining, 250L)
                delay(step)
                remaining -= step
            }

            var loop = 0
            while (macro.infinite || loop < macro.repeat) {
                loop++
                for ((i, action) in macro.actions.withIndex()) {
                    currentCoroutineContext().ensureActive()
                    while (paused) delay(50) // delay() tự kiểm tra hủy
                    val svc = GestureAccessibilityService.instance
                    if (svc == null) {
                        endMessage = "Accessibility bị ngắt — macro đã dừng"
                        return
                    }
                    publish(id) { Status(State.RUNNING, macro.name, i + 1, total, loop, loops, "") }
                    val ok = swipeAwait(svc, action.direction, action.durationMs)
                    if (!ok) {
                        endMessage = "⚠ Cú vuốt bị hủy/thất bại — macro đã dừng"
                        return
                    }
                    currentCoroutineContext().ensureActive()
                    delay(action.delayMs.toLong())
                }
            }
        } finally {
            synchronized(lock) {
                if (runId == id) {
                    job = null
                    _status.value = Status(message = endMessage)
                }
            }
        }
    }

    /**
     * Chờ callback hoàn tất. Giữ Mutex suốt thời gian cú vuốt đang diễn ra (kể cả khi bị hủy)
     * nên hai dispatchGesture không bao giờ chồng nhau. Có timeout phòng trường hợp
     * dịch vụ bị ngắt giữa chừng khiến callback không bao giờ tới.
     */
    private suspend fun swipeAwait(
        svc: GestureAccessibilityService,
        direction: Direction,
        durationMs: Int
    ): Boolean = gestureMutex.withLock {
        withContext(Dispatchers.Main + NonCancellable) {
            withTimeoutOrNull(durationMs + 2000L) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    svc.performSwipe(direction, SettingsRepository.load(), durationMs) { ok ->
                        if (cont.isActive) cont.resume(ok)
                    }
                }
            } ?: false
        }
    }
}
