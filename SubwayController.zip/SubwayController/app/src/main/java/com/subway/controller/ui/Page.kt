package com.subway.controller.ui

import android.app.Activity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlinx.coroutines.CoroutineScope

interface Host {
    fun showPage(index: Int)

    companion object {
        const val CONTROLLER = 0
        const val EDITOR = 1
        const val RECORDER = 2
        const val PRESETS = 3
        const val SETTINGS = 4
    }
}

interface Page {
    val title: String
    val view: View

    /** Gọi mỗi khi trang được hiển thị lại / Activity resume. */
    fun refresh() {}

    /** Gọi khi Activity onStart; hãy khởi chạy các collector trong [scope] (bị hủy ở onStop). */
    fun bind(scope: CoroutineScope) {}
}

/** Tạo ScrollView + LinearLayout dọc có padding, dùng chung cho các trang. */
fun scrollPage(act: Activity): Pair<ScrollView, LinearLayout> {
    val content = LinearLayout(act)
    content.orientation = LinearLayout.VERTICAL
    content.setPadding(act.dp(16), act.dp(16), act.dp(16), act.dp(24))
    val sv = ScrollView(act)
    sv.isFillViewport = false
    sv.addView(content, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
    return sv to content
}
