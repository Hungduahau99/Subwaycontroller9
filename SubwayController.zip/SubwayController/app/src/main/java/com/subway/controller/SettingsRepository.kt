package com.subway.controller

import android.content.Context
import android.content.SharedPreferences
import com.subway.controller.models.AppSettings

object SettingsRepository {
    private lateinit var prefs: SharedPreferences
    private lateinit var posPrefs: SharedPreferences

    fun init(context: Context) {
        val app = context.applicationContext
        prefs = app.getSharedPreferences("settings_v1", Context.MODE_PRIVATE)
        // Vị trí overlay lưu riêng để không kích hoạt listener đổi cài đặt.
        posPrefs = app.getSharedPreferences("overlay_pos_v1", Context.MODE_PRIVATE)
    }

    fun changeSource(): SharedPreferences = prefs

    private fun int(key: String, def: Int): Int =
        try { prefs.getInt(key, def) } catch (e: ClassCastException) { def }

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            int("delay", d.delayMs),
            int("duration", d.durationMs),
            int("startX", d.startXPct),
            int("startY", d.startYPct),
            int("distance", d.distancePct),
            int("alpha", d.overlayAlphaPct),
            int("size", d.overlaySizePct)
        ).sanitized()
    }

    fun save(s: AppSettings) {
        val c = s.sanitized()
        prefs.edit()
            .putInt("delay", c.delayMs)
            .putInt("duration", c.durationMs)
            .putInt("startX", c.startXPct)
            .putInt("startY", c.startYPct)
            .putInt("distance", c.distancePct)
            .putInt("alpha", c.overlayAlphaPct)
            .putInt("size", c.overlaySizePct)
            .apply()
    }

    fun reset() {
        prefs.edit().clear().apply()
        posPrefs.edit().clear().apply()
    }

    fun overlayPos(): Pair<Int, Int>? {
        if (!posPrefs.contains("x")) return null
        return try { posPrefs.getInt("x", 0) to posPrefs.getInt("y", 0) } catch (e: ClassCastException) { null }
    }

    fun saveOverlayPos(x: Int, y: Int) {
        posPrefs.edit().putInt("x", x).putInt("y", y).apply()
    }
}
