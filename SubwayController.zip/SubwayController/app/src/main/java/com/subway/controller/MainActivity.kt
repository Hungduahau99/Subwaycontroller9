package com.subway.controller

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.subway.controller.ui.ControllerPage
import com.subway.controller.ui.EditorPage
import com.subway.controller.ui.Host
import com.subway.controller.ui.Page
import com.subway.controller.ui.PresetsPage
import com.subway.controller.ui.RecorderPage
import com.subway.controller.ui.SettingsPage
import com.subway.controller.ui.Ui
import com.subway.controller.ui.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class MainActivity : Activity(), Host {
    private lateinit var pages: List<Page>
    private lateinit var content: FrameLayout
    private val navButtons = ArrayList<TextView>()
    private var uiScope: CoroutineScope? = null
    private var current = Host.CONTROLLER

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pages = listOf(
            ControllerPage(this),
            EditorPage(this),
            RecorderPage(this, this),
            PresetsPage(this, this),
            SettingsPage(this)
        )

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.fitsSystemWindows = true

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Ui.SURFACE)
        pages.forEachIndexed { i, p ->
            val tv = TextView(this)
            tv.text = p.title
            tv.textSize = 12f
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(12), 0, dp(12))
            tv.isClickable = true
            tv.setOnClickListener { showPage(i) }
            navButtons.add(tv)
            nav.addView(tv, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(root)

        showPage(savedInstanceState?.getInt("page", Host.CONTROLLER) ?: Host.CONTROLLER)
    }

    override fun showPage(index: Int) {
        val i = index.coerceIn(0, pages.lastIndex)
        current = i
        content.removeAllViews()
        val v: View = pages[i].view
        (v.parent as? android.view.ViewGroup)?.removeView(v)
        content.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        pages[i].refresh()
        navButtons.forEachIndexed { n, tv ->
            tv.setTextColor(if (n == i) Ui.ACCENT else Ui.MUTED)
        }
    }

    override fun onStart() {
        super.onStart()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        uiScope = scope
        pages.forEach { it.bind(scope) }
    }

    override fun onResume() {
        super.onResume()
        // Quay lại từ màn hình Cài đặt hệ thống: cập nhật trạng thái quyền.
        pages[current].refresh()
    }

    override fun onStop() {
        uiScope?.cancel()
        uiScope = null
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", current)
    }
}
