package com.subway.controller

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.subway.controller.models.AppSettings
import com.subway.controller.models.Direction
import com.subway.controller.util.Device

/**
 * Chỉ dùng để thực hiện thao tác vuốt do người dùng yêu cầu.
 * Không đọc / chụp / lưu nội dung màn hình và không xử lý sự kiện nào.
 */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GestureAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        MacroEngine.onServiceLost()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        MacroEngine.onServiceLost()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Cố ý không làm gì: dịch vụ không theo dõi màn hình.
    }

    override fun onInterrupt() {
        // Không có phản hồi nào cần ngắt.
    }

    /**
     * Gửi một cú vuốt. [onResult] được gọi đúng một lần:
     * true = hoàn tất; false = bị hủy / bị từ chối / lỗi.
     */
    fun performSwipe(
        direction: Direction,
        s: AppSettings,
        durationMs: Int,
        onResult: (Boolean) -> Unit
    ) {
        val (wi, hi) = Device.screenSize(this)
        val w = wi.toFloat()
        val h = hi.toFloat()
        val sx = (w * s.startXPct / 100f).coerceIn(1f, w - 1f)
        val sy = (h * s.startYPct / 100f).coerceIn(1f, h - 1f)
        val dist = (if (direction == Direction.LEFT || direction == Direction.RIGHT) w else h) *
            s.distancePct / 100f
        var ex = sx
        var ey = sy
        when (direction) {
            Direction.UP -> ey = sy - dist
            Direction.DOWN -> ey = sy + dist
            Direction.LEFT -> ex = sx - dist
            Direction.RIGHT -> ex = sx + dist
        }
        ex = ex.coerceIn(1f, w - 1f)
        ey = ey.coerceIn(1f, h - 1f)

        val gesture = try {
            val path = Path().apply {
                moveTo(sx, sy)
                lineTo(ex, ey)
            }
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.toLong()))
                .build()
        } catch (e: IllegalArgumentException) {
            onResult(false)
            return
        }

        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onResult(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onResult(false)
            }
        }, null)
        if (!accepted) onResult(false)
    }
}
