package com.subway.controller.ui

import android.app.Activity
import android.app.AlertDialog
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.subway.controller.ComboRecorder
import com.subway.controller.MacroEngine
import com.subway.controller.PresetRepository
import com.subway.controller.models.Direction
import com.subway.controller.models.Macro
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.UUID

class RecorderPage(private val act: Activity, private val host: Host) : Page {
    override val title = "Ghi combo"
    override val view: View

    private val stateText: TextView
    private val listText: TextView
    private val nameField: EditText

    init {
        val (sv, c) = scrollPage(act)
        view = sv

        c.addView(Ui.text(act, "Combo Recorder", 22f, Ui.TEXT, true))
        c.addView(Ui.muted(act,
            "Chức năng này CHỈ ghi lại việc bạn bấm các nút D-Pad của ứng dụng này " +
                "(trong tab này hoặc trên bảng điều khiển nổi) và khoảng thời gian giữa các lần bấm. " +
                "Nó không ghi thao tác cảm ứng thô khi chơi game, không ghi ứng dụng khác và không ghi nội dung màn hình."))
        c.addView(Ui.text(act, "", 6f))

        val rec = Ui.card(act)
        stateText = Ui.text(act, "", 15f, Ui.TEXT, true)
        rec.addView(stateText)
        val r1 = Ui.row(act)
        r1.addView(Ui.dangerButton(act, "● Bắt đầu ghi") { ComboRecorder.start() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        r1.addView(Ui.button(act, "■ Dừng ghi") { ComboRecorder.stop() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        rec.addView(r1, Ui.lp())
        rec.addView(Ui.text(act, "", 6f))

        val dpadHolder = android.widget.LinearLayout(act)
        dpadHolder.gravity = android.view.Gravity.CENTER
        val center = Ui.text(act, "●", 18f, Ui.MUTED).apply { gravity = android.view.Gravity.CENTER }
        dpadHolder.addView(Ui.dpad(act, act.dp(64), center) { d -> onDpad(d) })
        rec.addView(dpadHolder, Ui.lp())
        rec.addView(Ui.muted(act,
            "D-Pad trong tab này chỉ để ghi (không vuốt lên màn hình). Muốn ghi lúc đang chơi, " +
                "bật bảng điều khiển nổi và bấm nút “● Ghi” trên đó."))
        c.addView(rec)

        val seq = Ui.card(act)
        seq.addView(Ui.heading(act, "Combo đã ghi"))
        listText = Ui.text(act, "")
        seq.addView(listText)
        seq.addView(Ui.text(act, "", 6f))
        nameField = EditText(act).apply {
            setSingleLine()
            setText("Combo mới")
            setTextColor(Ui.TEXT)
            setSelectAllOnFocus(true)
        }
        seq.addView(nameField, Ui.lp())

        val r2 = Ui.row(act)
        r2.addView(Ui.button(act, "Xem trước") { preview() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        r2.addView(Ui.button(act, "Xóa") { ComboRecorder.clear() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        seq.addView(r2, Ui.lp())
        val r3 = Ui.row(act)
        r3.addView(Ui.button(act, "Sửa trong Macro Editor") { editInEditor() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        r3.addView(Ui.primaryButton(act, "Lưu preset") { save() }, Ui.lp(0, Ui.WRAP, 1f, act.dp(2)))
        seq.addView(r3, Ui.lp())
        c.addView(seq)

        render(ComboRecorder.state.value)
    }

    override fun bind(scope: CoroutineScope) {
        scope.launch { ComboRecorder.state.collect { render(it) } }
    }

    private fun render(st: ComboRecorder.State) {
        stateText.text = if (st.recording) "🔴 Đang ghi… (${st.actions.size} bước)" else "⚪ Không ghi (${st.actions.size} bước)"
        stateText.setTextColor(if (st.recording) Ui.DANGER else Ui.TEXT)
        listText.text = if (st.actions.isEmpty()) "Chưa có bước nào." else
            st.actions.mapIndexed { i, a -> "${i + 1}. ${a.direction.arrow} ${a.direction.label}  (trễ ${a.delayMs}ms)" }
                .joinToString("\n")
    }

    private fun onDpad(d: Direction) {
        if (!ComboRecorder.state.value.recording) {
            Ui.toast(act, "Hãy bấm “Bắt đầu ghi” trước")
            return
        }
        ComboRecorder.record(d)
    }

    private fun currentMacro(): Macro? {
        val actions = ComboRecorder.state.value.actions
        if (actions.isEmpty()) {
            Ui.toast(act, "Chưa ghi bước nào")
            return null
        }
        val name = nameField.text.toString().trim().ifBlank { "Combo" }.take(60)
        return Macro(name = name, actions = actions)
    }

    private fun preview() {
        val m = currentMacro() ?: return
        AlertDialog.Builder(act)
            .setTitle(m.name)
            .setMessage("${m.summary()}\n\n${m.actions.size} bước • ~${"%.1f".format(m.estimatedLoopMs() / 1000.0)}s")
            .setPositiveButton("Chạy thử sau 5s") { _, _ ->
                when (MacroEngine.start(m, 5000L)) {
                    MacroEngine.StartResult.OK -> Ui.toast(act, "Hãy chuyển sang game…")
                    MacroEngine.StartResult.NO_SERVICE -> Ui.toast(act, "Chưa bật dịch vụ Trợ năng")
                    MacroEngine.StartResult.BUSY -> Ui.toast(act, "Một macro đang chạy")
                    MacroEngine.StartResult.EMPTY -> {}
                }
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun editInEditor() {
        val m = currentMacro() ?: return
        PresetRepository.saveWorking(m)
        host.showPage(Host.EDITOR)
    }

    private fun save() {
        val m = currentMacro() ?: return
        PresetRepository.save(m.copy(id = UUID.randomUUID().toString()))
        Ui.toast(act, "Đã lưu preset “${m.name}”")
    }
}
