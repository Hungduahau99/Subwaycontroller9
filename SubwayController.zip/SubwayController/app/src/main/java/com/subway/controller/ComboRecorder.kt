package com.subway.controller

import com.subway.controller.models.Direction
import com.subway.controller.models.Limits
import com.subway.controller.models.MacroAction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Chỉ ghi lại việc bấm các nút D-Pad CỦA CHÍNH ỨNG DỤNG NÀY (trong app hoặc trên bảng điều khiển nổi)
 * cùng khoảng thời gian giữa hai lần bấm. Không ghi cảm ứng thô, không ghi ứng dụng khác,
 * không ghi nội dung màn hình.
 */
object ComboRecorder {
    data class State(val recording: Boolean = false, val actions: List<MacroAction> = emptyList())

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private val lock = Any()
    private var lastTime = 0L

    fun start() = synchronized(lock) {
        lastTime = 0L
        _state.value = _state.value.copy(recording = true)
    }

    fun stop() = synchronized(lock) {
        lastTime = 0L
        _state.value = _state.value.copy(recording = false)
    }

    fun clear() = synchronized(lock) {
        lastTime = 0L
        _state.value = _state.value.copy(actions = emptyList())
    }

    fun setActions(actions: List<MacroAction>) = synchronized(lock) {
        _state.value = _state.value.copy(actions = actions)
    }

    /** [nowMs] mặc định là đồng hồ đơn điệu; tham số để dễ kiểm thử. */
    fun record(
        direction: Direction,
        nowMs: Long = android.os.SystemClock.elapsedRealtime()
    ) {
        synchronized(lock) {
            val s = _state.value
            if (!s.recording || s.actions.size >= Limits.MAX_ACTIONS) return
            val cfg = SettingsRepository.load()
            val list = s.actions.toMutableList()
            if (lastTime != 0L && list.isNotEmpty()) {
                val prev = list.last()
                val interval = (nowMs - lastTime).coerceIn(0L, 60_000L).toInt()
                list[list.lastIndex] =
                    prev.copy(delayMs = (interval - prev.durationMs).coerceIn(Limits.DELAY_MIN, Limits.DELAY_MAX))
            }
            list.add(MacroAction(direction, cfg.delayMs, cfg.durationMs))
            lastTime = nowMs
            _state.value = s.copy(actions = list)
        }
    }
}
