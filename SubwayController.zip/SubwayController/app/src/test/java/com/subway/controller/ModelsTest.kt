package com.subway.controller

import com.subway.controller.models.AppSettings
import com.subway.controller.models.Direction
import com.subway.controller.models.Limits
import com.subway.controller.models.Macro
import com.subway.controller.models.MacroAction
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelsTest {
    @Test
    fun macroRoundTrip() {
        val m = Macro(
            name = "Test", repeat = 3, infinite = true,
            actions = listOf(MacroAction(Direction.UP, 120, 80), MacroAction(Direction.LEFT, 0, 1000))
        )
        val back = Macro.fromJson(JSONObject(m.toJson().toString()))
        assertEquals(m, back)
    }

    @Test
    fun fromJsonClampsAndSkipsBadActions() {
        val raw = """{"name":"x","repeat":-5,"actions":[{"d":"UP","delay":99999,"dur":1},{"d":"NOPE"},{"foo":1}]}"""
        val m = Macro.fromJson(JSONObject(raw))
        assertEquals(1, m.actions.size)
        assertEquals(Limits.DELAY_MAX, m.actions[0].delayMs)
        assertEquals(Limits.DURATION_MIN, m.actions[0].durationMs)
        assertEquals(Limits.REPEAT_MIN, m.repeat)
    }

    @Test
    fun presetParsingToleratesLegacyAndCorruptData() {
        val legacy = """[{"name":"old","actions":[{"d":"DOWN"}]}]"""
        assertEquals("old", PresetRepository.parse(legacy).single().name)

        val versioned = """{"version":1,"presets":[{"name":"a"},{"name":"b"}]}"""
        assertEquals(2, PresetRepository.parse(versioned).size)

        assertTrue(PresetRepository.parse("{not json").isEmpty())
        assertTrue(PresetRepository.parse(null).isEmpty())
    }

    @Test
    fun settingsAreSanitized() {
        val s = AppSettings(delayMs = -1, durationMs = 5000, startXPct = 500, distancePct = 0).sanitized()
        assertEquals(Limits.DELAY_MIN, s.delayMs)
        assertEquals(Limits.DURATION_MAX, s.durationMs)
        assertEquals(100, s.startXPct)
        assertEquals(5, s.distancePct)
    }
}
