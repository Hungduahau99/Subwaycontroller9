# Subway Controller (Android, Kotlin)

Bảng điều khiển nổi cho Subway Surfers: D-Pad vuốt ↑ ↓ ← → + macro combo, qua `AccessibilityService.dispatchGesture()`.
Không cần root, không dùng mạng (không khai báo quyền INTERNET), không thu thập dữ liệu.

> **Trạng thái:** mã nguồn đầy đủ nhưng **chưa được biên dịch/kiểm thử** trong môi trường tạo ra nó
> (không có Android SDK/Gradle/mạng). Chưa có APK. Hãy build theo hướng dẫn bên dưới và báo lỗi nếu có.

## Phiên bản
| Thành phần | Giá trị |
|---|---|
| compileSdk / targetSdk / minSdk | 34 / 34 / 26 |
| Android Gradle Plugin | 8.5.2 |
| Gradle | 8.7 |
| Kotlin | 1.9.24 |
| JDK | 17 |

## Build
**Cách 1 – Android Studio (Koala+):** mở thư mục dự án → Sync → *Build › Build APK(s)*.

**Cách 2 – dòng lệnh** (cần JDK 17 + Android SDK 34, đặt `ANDROID_HOME`):
```bash
gradle wrapper --gradle-version 8.7   # chỉ lần đầu, để tạo gradlew + gradle-wrapper.jar
./gradlew testDebugUnitTest assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

**Cách 3 – GitHub Actions:** đẩy lên GitHub, workflow `.github/workflows/build-apk.yml` build và đính kèm APK dạng artifact.

## Cài đặt trên Android 13+
1. Cài APK (cho phép “cài từ nguồn không rõ”).
2. Mở app → **Mở cài đặt quyền hiển thị** → bật “Hiển thị trên ứng dụng khác” cho Subway Controller.
3. **Mở cài đặt Trợ năng** → *Ứng dụng đã cài* → Subway Controller → bật.
   - Nếu mục bị mờ (APK cài ngoài Play): *Cài đặt › Ứng dụng › Subway Controller › ⋮ › Cho phép cài đặt bị hạn chế*, rồi bật lại.
4. Tab **Cài đặt**: chỉnh điểm bắt đầu/quãng vuốt, bấm **Hiện điểm vuốt** để đối chiếu với màn hình game.
5. Tab **Điều khiển** → **Bật bộ điều khiển nổi** → mở game.

## Dùng nhanh
- Nút tròn “S” mở/đóng bảng; kéo để di chuyển (kéo cả viền bảng). “✕” tắt bộ điều khiển. “■” giữa D-Pad = **dừng khẩn cấp**.
- Soạn macro ở tab **Macro** (thêm/xóa/sắp xếp, trễ, thời lượng, số vòng/vô hạn). Nút **▶ Chạy** trên bảng nổi chạy macro đang soạn.
- **Ghi combo**: bấm “● Ghi” (trong tab hoặc trên bảng nổi), bấm D-Pad; app lưu hướng + khoảng cách thời gian. Chỉ ghi các nút D-Pad của chính app này.
- **Preset**: lưu, tải, đổi tên, nhân bản, xóa. Dữ liệu JSON có phiên bản, lưu cục bộ (SharedPreferences).

## Quyền & quyền riêng tư
- `SYSTEM_ALERT_WINDOW`: vẽ bảng nổi. `FOREGROUND_SERVICE(_SPECIAL_USE)` + `POST_NOTIFICATIONS`: giữ dịch vụ sống, hiện thông báo (từ chối thông báo vẫn dùng được).
- Dịch vụ Trợ năng khai báo `canPerformGestures=true`, `canRetrieveWindowContent=false`, không đăng ký sự kiện nào, `isAccessibilityTool=false` (đây là công cụ macro game, không phải công cụ hỗ trợ người khuyết tật).

## Giới hạn đã biết
- Cú vuốt gửi tới **tọa độ màn hình**; đừng để bảng nổi che điểm bắt đầu. Game/Android có thể xử lý cảm ứng giả khác nhau.
- Tạm dừng có hiệu lực **giữa các cú vuốt**. Dừng khẩn cấp hủy mọi việc đang chờ; cú vuốt đang bay (≤ 1 giây) không thể thu hồi nhưng không có cú vuốt mới nào được gửi.
- Preview của combo = tóm tắt + chạy thử sau 5 giây (vì app đang ở nền khi bạn chuyển sang game).
- Hiệu chỉnh hiện dùng một điểm bắt đầu và một quãng vuốt chung cho cả 4 hướng.
- Không có cách nào để vượt qua cơ chế chống gian lận hay hạn chế của Android — app không cố làm vậy.

## Xử lý sự cố
| Hiện tượng | Cách xử lý |
|---|---|
| Nút bấm nhưng không vuốt | Kiểm tra trạng thái Trợ năng ở tab Điều khiển; tắt/bật lại dịch vụ. |
| Vuốt trúng bảng nổi | Đổi điểm bắt đầu (tab Cài đặt) hoặc kéo bảng đi chỗ khác. |
| Macro tự dừng | Xem dòng trạng thái: thường do Trợ năng bị ngắt hoặc cú vuốt bị hủy. Bật lại dịch vụ. |
| Không bật được Trợ năng | Làm bước “Cho phép cài đặt bị hạn chế” ở trên. |
| Bảng nổi biến mất | Một số ROM tiết kiệm pin kill dịch vụ: tắt tối ưu pin cho app. |
